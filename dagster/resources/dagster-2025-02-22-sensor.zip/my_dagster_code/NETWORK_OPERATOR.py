#from dagster import job, op, get_dagster_logger, Definitions 
from dagster import (
    job, 
    op,  
    get_dagster_logger,  
)
import pandas as pd
#import sqlalchemy  
#from definitions import get_db_connection, calculate_sha256_hash 
import psycopg2 # For PostgreSQL interaction 
from dotenv import load_dotenv 
import os
from datetime import datetime 
from typing import Union
from io import BytesIO 
from MM_BIL import process_mm_bil_data

load_dotenv(dotenv_path="configs.env")  # Create this file

DB_HOST = os.getenv('DB_HOST')
DB_NAME = os.getenv('DB_NAME')
DB_USER = os.getenv('DB_USER')  # Simplified endpoint URL
DB_PASSWORD = os.getenv('DB_PASSWORD')  # Simplified endpoint URL
  
@op
def process_mm_wechsel_data(context):
    logger = get_dagster_logger()
    try:
        conn = psycopg2.connect(host=DB_HOST, database=DB_NAME, user=DB_USER, password=DB_PASSWORD)
        cur = conn.cursor()

        logger.info("STARTING MM_Wechsel WHOLE DATA TRANSFORMATION...")
        cur.execute("SELECT json_data, file_id FROM File_data WHERE sheet_name = %s", ("MM_Wechsel",))
        data = cur.fetchall() 

        transformed_data = transform_data(data)
        #logger.info(f"MM_Wechsel -- transformed_data data: {transformed_data}")
        
        for row in transformed_data:
            try:
                # Construct the INSERT statement dynamically based on your mm_wechsel table structure
                columns = ", ".join(row.keys())  # Get column names from the row
                placeholders = ", ".join(["%s"] * len(row))  # Create placeholders
                 
                #logger.info(f"MM_Wechsel -- columns: {columns}")
                #logger.info(f"MM_Wechsel -- placeholders: {placeholders}")
                
                insert_statement = f"INSERT INTO vw.mm_wechsel ({columns}) VALUES ({placeholders})"

                # Extract values in the same order as columns
                values = tuple(row.values())

                cur.execute(insert_statement, values)
                conn.commit()
                
                logger.info("FINISH MM_Wechsel WHOLE DATA TRANSFORMATION...")
            except psycopg2.Error as e:
                conn.rollback()
                logger.error(f"Error inserting row: {row}. Error: {e}")  # Include error message
                raise  # Re-raise the exception
            
    except psycopg2.Error as e:
        logger.error(f"Database connection error: {e}")
        raise

    finally:
        if conn:
            cur.close()
            conn.close()
            logger.info("Database connection closed.")


def transform_data(data):
    logger = get_dagster_logger()
    logger.info("Starting MM_Wechsel data transformation...")
    #logger.info(f"Received MM_Wechsel data: {data}")

    new_rows = []

    if not data or not data[0][0]:
        logger.error("No data provided for MM_Wechsel transformation")
        return []

    for item in data: # Iterate over each item from the list of tuples
        json_data = item[0]  # Get the JSON dictionary
        file_id = item[1]  # Get file_id
        #kunde_id = item[1]  # Get kunde_id

        year = json_data.get('Q9')  # Get the year from 'Q9'

        if not year: 
            logger.error(f"No data provided for YEAR{json_data}, for MM_Wechsel transformation") 
            continue  # Skip to the next item if no year is found

        # Map month numbers to column prefixes
        month_columns = {
            1: 'E', 2: 'F', 3: 'G', 4: 'H', 5: 'I', 6: 'J',
            7: 'K', 8: 'L', 9: 'M', 10: 'N', 11: 'O', 12: 'P'
        }

        # Create a row for each month
        for month_num in range(1, 13):
            prefix = month_columns[month_num]

            new_row = {
                'kunde_id': 1,  # Use the retrieved kunde_id
                'monat': month_num, # get_month_name(month_num),
                'file_id': file_id,
                'jahr': 2024, #year,
                'vk_bis_5600_kwh': json_data.get(f'{prefix}11', None),  # Example: Adapt cell references
                'vk_uber_5600_kwh_bis_55600_kwh': json_data.get(f'{prefix}12', None),
                'vk_uber_5600_kwh': json_data.get(f'{prefix}13', None),
                'vk_bis_278_mwha': json_data.get(f'{prefix}15', None),
                'vk_von_278_mwha_bis_400_mwha': json_data.get(f'{prefix}16', None),
                'vk_von_400_mwha_bis_2778_mwha': json_data.get(f'{prefix}17', None),
                'vk_von_2778_mwha_bis_5595_mwha': json_data.get(f'{prefix}18', None),
                'vk_von_5595_mwha_bis_27778_mwha': json_data.get(f'{prefix}19', None),
                'vk_von_27778_mwha_bis_277778_mwha': json_data.get(f'{prefix}20', None),
                'vk_von_277778_mwha_bis_1111111_mwha': json_data.get(f'{prefix}21', None),
                'vk_uber_1111111_mwha': json_data.get(f'{prefix}22', None),
                'at900029_z_h': json_data.get(f'{prefix}35', None),
                'at900029_z_nh': json_data.get(f'{prefix}36', None),
                'at900029_a_h': json_data.get(f'{prefix}37', None),
                'at900029_a_nh': json_data.get(f'{prefix}38', None),
                'at900089_z_h': json_data.get(f'{prefix}39', None),
                'at900089_z_nh': json_data.get(f'{prefix}40', None),
                'at900089_a_h': json_data.get(f'{prefix}41', None),
                'at900089_a_nh': json_data.get(f'{prefix}42', None),
                'at900119_z_h': json_data.get(f'{prefix}43', None),  # Adapt cell references
                'at900119_z_nh': json_data.get(f'{prefix}44', None),
                'at900119_a_h': json_data.get(f'{prefix}45', None),
                'at900119_a_nh': json_data.get(f'{prefix}46', None),
                'at900199_z_h': json_data.get(f'{prefix}47', None),
                'at900199_z_nh': json_data.get(f'{prefix}48', None),
                'at900199_a_h': json_data.get(f'{prefix}49', None),
                'at900199_a_nh': json_data.get(f'{prefix}50', None),
                'at900209_z_h': json_data.get(f'{prefix}51', None),
                'at900209_z_nh': json_data.get(f'{prefix}52', None),
                'at900209_a_h': json_data.get(f'{prefix}53', None),
                'at900209_a_nh': json_data.get(f'{prefix}54', None),
                'at900239_z_h': json_data.get(f'{prefix}55', None),
                'at900239_z_nh': json_data.get(f'{prefix}56', None),
                'at900239_a_h': json_data.get(f'{prefix}57', None),
                'at900239_a_nh': json_data.get(f'{prefix}58', None),
                'at900279_z_h': json_data.get(f'{prefix}59', None),
                'at900279_z_nh': json_data.get(f'{prefix}60', None),
                'at900279_a_h': json_data.get(f'{prefix}61', None),
                'at900279_a_nh': json_data.get(f'{prefix}62', None),
                'at900299_z_h': json_data.get(f'{prefix}63', None),
                'at900299_z_nh': json_data.get(f'{prefix}64', None),
                'at900299_a_h': json_data.get(f'{prefix}65', None),
                'at900299_a_nh': json_data.get(f'{prefix}66', None),
                'at900349_z_h': json_data.get(f'{prefix}67', None),
                'at900349_z_nh': json_data.get(f'{prefix}68', None),
                'at900349_a_h': json_data.get(f'{prefix}69', None),
                'at900349_a_nh': json_data.get(f'{prefix}70', None),
                'at900379_z_h': json_data.get(f'{prefix}71', None),
                'at900379_z_nh': json_data.get(f'{prefix}72', None),
                'at900379_a_h': json_data.get(f'{prefix}73', None),
                'at900379_a_nh': json_data.get(f'{prefix}74', None),
                'at900429_z_h': json_data.get(f'{prefix}75', None),
                'at900429_z_nh': json_data.get(f'{prefix}76', None),
                'at900429_a_h': json_data.get(f'{prefix}77', None),
                'at900429_a_nh': json_data.get(f'{prefix}78', None),
                'at900509_z_h': json_data.get(f'{prefix}79', None),
                'at900509_z_nh': json_data.get(f'{prefix}80', None),
                'at900509_a_h': json_data.get(f'{prefix}81', None),
                'at900509_a_nh': json_data.get(f'{prefix}82', None),
                'at900529_z_h': json_data.get(f'{prefix}83', None),
                'at900529_z_nh': json_data.get(f'{prefix}84', None),
                'at900529_a_h': json_data.get(f'{prefix}85', None),
                'at900529_a_nh': json_data.get(f'{prefix}86', None),
                'at900559_z_h': json_data.get(f'{prefix}87', None),
                'at900559_z_nh': json_data.get(f'{prefix}88', None),
                'at900559_a_h': json_data.get(f'{prefix}89', None),
                'at900559_a_nh': json_data.get(f'{prefix}90', None),
                'at900599_z_h': json_data.get(f'{prefix}91', None),
                'at900599_z_nh': json_data.get(f'{prefix}92', None),
                'at900599_a_h': json_data.get(f'{prefix}93', None),
                'at900599_a_nh': json_data.get(f'{prefix}94', None),
                'at900699_z_h': json_data.get(f'{prefix}95', None),
                'at900699_z_nh': json_data.get(f'{prefix}96', None),
                'at900699_a_h': json_data.get(f'{prefix}97', None),
                'at900699_a_nh': json_data.get(f'{prefix}98', None),
                'at900929_z_h': json_data.get(f'{prefix}99', None),
                'at900929_z_nh': json_data.get(f'{prefix}100', None),
                'at900929_a_h': json_data.get(f'{prefix}101', None),
                'at900929_a_nh': json_data.get(f'{prefix}102', None),
                'at901179_z_h': json_data.get(f'{prefix}103', None),
                'at901179_z_nh': json_data.get(f'{prefix}104', None),
                'at901179_a_h': json_data.get(f'{prefix}105', None),
                'at901179_a_nh': json_data.get(f'{prefix}106', None),
                'at901189_z_h': json_data.get(f'{prefix}107', None),
                'at901189_z_nh': json_data.get(f'{prefix}108', None),
                'at901189_a_h': json_data.get(f'{prefix}109', None),
                'at901189_a_nh': json_data.get(f'{prefix}110', None),
                'at901201_z_h': json_data.get(f'{prefix}111', None),
                'at901201_z_nh': json_data.get(f'{prefix}112', None),
                'at901201_a_h': json_data.get(f'{prefix}113', None),
                'at901201_a_nh': json_data.get(f'{prefix}114', None),
                'at901419_z_h': json_data.get(f'{prefix}115', None),
                'at901419_z_nh': json_data.get(f'{prefix}116', None),
                'at901419_a_h': json_data.get(f'{prefix}117', None),
                'at901419_a_nh': json_data.get(f'{prefix}118', None),
                'at901539_z_h': json_data.get(f'{prefix}119', None),
                'at901539_z_nh': json_data.get(f'{prefix}120', None),
                'at901539_a_h': json_data.get(f'{prefix}121', None),
                'at901539_a_nh': json_data.get(f'{prefix}122', None),
                'at901649_z_h': json_data.get(f'{prefix}123', None),
                'at901649_z_nh': json_data.get(f'{prefix}124', None),
                'at901649_a_h': json_data.get(f'{prefix}125', None),
                'at901649_a_nh': json_data.get(f'{prefix}126', None),
                'at901729_z_h': json_data.get(f'{prefix}127', None),
                'at901729_z_nh': json_data.get(f'{prefix}128', None),
                'at901729_a_h': json_data.get(f'{prefix}129', None),
                'at901729_a_nh': json_data.get(f'{prefix}130', None),
                'at901739_z_h': json_data.get(f'{prefix}131', None),
                'at901739_z_nh': json_data.get(f'{prefix}132', None),
                'at901739_a_h': json_data.get(f'{prefix}133', None),
                'at901739_a_nh': json_data.get(f'{prefix}134', None),
                'at901789_z_h': json_data.get(f'{prefix}135', None),
                'at901789_z_nh': json_data.get(f'{prefix}136', None),
                'at901789_a_h': json_data.get(f'{prefix}137', None),
                'at901789_a_nh': json_data.get(f'{prefix}138', None),
                'at901919_z_h': json_data.get(f'{prefix}139', None),
                'at901919_z_nh': json_data.get(f'{prefix}140', None),
                'at901919_a_h': json_data.get(f'{prefix}141', None),
                'at901919_a_nh': json_data.get(f'{prefix}142', None),
                'at901929_z_h': json_data.get(f'{prefix}143', None),
                'at901929_z_nh': json_data.get(f'{prefix}144', None),
                'at901929_a_h': json_data.get(f'{prefix}145', None),
                'at901929_a_nh': json_data.get(f'{prefix}146', None),
                'at901959_z_h': json_data.get(f'{prefix}147', None),
                'at901959_z_nh': json_data.get(f'{prefix}148', None),
                'at901959_a_h': json_data.get(f'{prefix}149', None),
                'at901959_a_nh': json_data.get(f'{prefix}150', None),
                'at901999_z_h': json_data.get(f'{prefix}151', None),
                'at901999_z_nh': json_data.get(f'{prefix}152', None),
                'at901999_a_h': json_data.get(f'{prefix}153', None),
                'at901999_a_nh': json_data.get(f'{prefix}154', None),
                'at902009_z_h': json_data.get(f'{prefix}155', None),
                'at902009_z_nh': json_data.get(f'{prefix}156', None),
                'at902009_a_h': json_data.get(f'{prefix}157', None),
                'at902009_a_nh': json_data.get(f'{prefix}158', None),
                'at902149_z_h': json_data.get(f'{prefix}159', None),
                'at902149_z_nh': json_data.get(f'{prefix}160', None),
                'at902149_a_h': json_data.get(f'{prefix}161', None),
                'at902149_a_nh': json_data.get(f'{prefix}162', None),
                'at902169_z_h': json_data.get(f'{prefix}163', None),
                'at902169_z_nh': json_data.get(f'{prefix}164', None),
                'at902169_a_h': json_data.get(f'{prefix}165', None),
                'at902169_a_nh': json_data.get(f'{prefix}166', None),
                'at902179_z_h': json_data.get(f'{prefix}167', None),
                'at902179_z_nh': json_data.get(f'{prefix}168', None),
                'at902179_a_h': json_data.get(f'{prefix}169', None),
                'at902189_z_h': json_data.get(f'{prefix}171', None),
                'at902189_z_nh': json_data.get(f'{prefix}172', None),
                'at902189_a_h': json_data.get(f'{prefix}173', None),
                'at902189_a_nh': json_data.get(f'{prefix}174', None),
                'at902209_z_h': json_data.get(f'{prefix}175', None),
                'at902209_z_nh': json_data.get(f'{prefix}176', None),
                'at902209_a_h': json_data.get(f'{prefix}177', None),
                'at902209_a_nh': json_data.get(f'{prefix}178', None),
                'at902269_z_h': json_data.get(f'{prefix}179', None),
                'at902269_z_nh': json_data.get(f'{prefix}180', None),
                'at902269_a_h': json_data.get(f'{prefix}181', None),
                'at902269_a_nh': json_data.get(f'{prefix}182', None),
                'at902299_z_h': json_data.get(f'{prefix}183', None),
                'at902299_z_nh': json_data.get(f'{prefix}184', None),
                'at902299_a_h': json_data.get(f'{prefix}185', None),
                'at902299_a_nh': json_data.get(f'{prefix}186', None),
                'at902329_z_h': json_data.get(f'{prefix}187', None),
                'at902329_z_nh': json_data.get(f'{prefix}188', None),
                'at902329_a_h': json_data.get(f'{prefix}189', None),
                'at902329_a_nh': json_data.get(f'{prefix}190', None),
                'at902349_z_h': json_data.get(f'{prefix}191', None),
                'at902349_z_nh': json_data.get(f'{prefix}192', None),
                'at902349_a_h': json_data.get(f'{prefix}193', None),
                'at902349_a_nh': json_data.get(f'{prefix}194', None),
                # Add other mm_wechsel-specific fields similarly
            }
            #logger.info(f"Created row for month {month_num}: {new_row}") # Log the row being created
            new_rows.append(new_row)

    return new_rows


def convert_to_float(value):
    if value is None:
        return None
    try:
        return float(value)
    except (ValueError, TypeError):
        return None  # Return None if conversion fails


# Helper functions (you'll need to implement these based on your data)
def get_month_name(month_number):
    month_names = ["Jänner", "Februar", "März", "April", "Mai", "Juni", 
                   "Juli", "August", "September", "Oktober", "November", "Dezember"]
    return month_names[month_number - 1] if 1 <= month_number <= 12 else None

def get_month_column(month_number):
    # Map month number to column identifier (e.g., "C11", "D11", etc.)
    # Adjust these based on your actual column identifiers
    month_columns = {
        1: "C11", 2: "D11", 3: "E11", 4: "F11", 5: "G11", 6: "H11",
        7: "I11", 8: "J11", 9: "K11", 10: "L11", 11: "M11", 12: "N11"
    }
    return month_columns.get(month_number)        

@job
def parse_network_operator_job(): 
    process_mm_wechsel_data()  
    process_mm_bil_data()  