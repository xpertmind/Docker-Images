#from dagster import job, op, get_dagster_logger, Definitions 
from dagster import (
    job, 
    op, 
    get_dagster_logger, 
    Definitions, 
)
import pandas as pd 
#from definitions import get_db_connection, calculate_sha256_hash
import psycopg2 # For PostgreSQL interaction 
from dotenv import load_dotenv 
import os
from datetime import datetime 
from typing import Union
from io import BytesIO

load_dotenv(dotenv_path="configs.env")  # Create this file

DB_HOST = os.getenv('DB_HOST')
DB_NAME = os.getenv('DB_NAME')
DB_USER = os.getenv('DB_USER')  # Simplified endpoint URL
DB_PASSWORD = os.getenv('DB_PASSWORD')  # Simplified endpoint URL
        
@op
def process_mm_bil_data(context):
    logger = get_dagster_logger()
    try:
        conn = psycopg2.connect(host=DB_HOST, database=DB_NAME, user=DB_USER, password=DB_PASSWORD)
        cur = conn.cursor()

        cur.execute("SELECT json_data, file_id FROM File_data WHERE sheet_name = %s", ("MM_Bil",))
        data = cur.fetchall()

        transformed_data = transform_data(data)
        logger.info(f"AAAA transformed_data data: {transformed_data}")

        for row in transformed_data:
            try:

                cur.execute("INSERT INTO vw.mm_bil (file_id, kunde_id, monat, jahr, netz_abgabe_endverbraucher,  netz_eigenverbrauch_fernleitung, netz_eigenverbrauch_verteiler, netz_verluste, netz_einspeisung_biogen, netz_abgabe_geschuetzt,  netz_abgabe_haushalt, netz_abgabe_sozial, netz_abgabe_leistungsgemessen) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", (
                    convert_to_float(row.get('file_id')),
                    convert_to_float(row.get('kunde_id')),
                    convert_to_float(row.get('monat')),
                    convert_to_float(row.get('jahr')),
                    convert_to_float(row.get('netz_abgabe_endverbraucher')),
                    convert_to_float(row.get('netz_eigenverbrauch_fernleitung')),
                    convert_to_float(row.get('netz_eigenverbrauch_verteiler')),
                    convert_to_float(row.get('netz_verluste')),
                    convert_to_float(row.get('netz_einspeisung_biogen')),
                    convert_to_float(row.get('netz_abgabe_geschuetzt')),
                    convert_to_float(row.get('netz_abgabe_haushalt')),
                    convert_to_float(row.get('netz_abgabe_sozial')),
                    convert_to_float(row.get('netz_abgabe_leistungsgemessen')),
                ))
                conn.commit()
            except psycopg2.Error as e:
                conn.rollback()
                logger.error(f"Error inserting row: {row}")
                raise  # Re-raise the exception

    except psycopg2.Error as e:
        logger.error(f"Database connection error: {e}")
        raise

    finally:
        if conn:
            cur.close()
            conn.close()
            logger.info("Database connection closed.")


def transform_data(data):
    logger = get_dagster_logger()
    logger.info("Starting data transformation...")
    logger.info(f"All together data are: {data}")
    
    new_rows = []
    
    if not data or not data[0][0]:
        logger.error("No data provided for transformation")
        return []

    json_data = data[0][0]  # Get the JSON dictionary
    file_id = data[0][1]  # Get the JSON dictionary
    year = 2024  # Based on your data, this is fixed for now
    
    # Map month numbers to column prefixes
    month_columns = {
        1: 'C', 2: 'D', 3: 'E', 4: 'F', 5: 'G', 6: 'H',
        7: 'I', 8: 'J', 9: 'K', 10: 'L', 11: 'M', 12: 'N'
    }
    
    # Create a row for each month
    for month_num in range(1, 13):
        prefix = month_columns[month_num]
        
        # Skip if no data for this month (checking if endverbraucher exists)
        #if f'{prefix}11' not in json_data:
        #    continue
            
        new_row = {
            'kunde_id': "kunde_id",  # You might want to pass this as a parameter
            'monat': month_num, #get_month_name(month_num),
            'file_id': file_id,
            'jahr': year,
            'netz_abgabe_endverbraucher': json_data.get(f'{prefix}11', None),
            'netz_eigenverbrauch_fernleitung': json_data.get(f'{prefix}12', None),  # Not present in JSON
            'netz_eigenverbrauch_verteiler': json_data.get(f'{prefix}13', None),
            'netz_verluste': json_data.get(f'{prefix}14', None),
            'netz_einspeisung_biogen': json_data.get(f'{prefix}29', None),
            'netz_abgabe_geschuetzt': json_data.get(f'{prefix}30', None),
            'netz_abgabe_haushalt': json_data.get(f'{prefix}31', None),
            'netz_abgabe_sozial': json_data.get(f'{prefix}32', None),
            'netz_abgabe_leistungsgemessen': json_data.get(f'{prefix}34', None)
        }
        
        # Log the row being created
        logger.info(f"Created row for month {month_num}: {new_row}")
        new_rows.append(new_row)
    
    return new_rows


def convert_to_float(value):
    if value is None:
        return None
    try:
        return float(value)
    except (ValueError, TypeError):
        return None  # Return None if conversion fails


# Helper functions (you'll need to implement these based on your data)
def get_month_name(month_number):
    month_names = ["Jänner", "Februar", "März", "April", "Mai", "Juni", 
                   "Juli", "August", "September", "Oktober", "November", "Dezember"]
    return month_names[month_number - 1] if 1 <= month_number <= 12 else None

def get_month_column(month_number):
    # Map month number to column identifier (e.g., "C11", "D11", etc.)
    # Adjust these based on your actual column identifiers
    month_columns = {
        1: "C11", 2: "D11", 3: "E11", 4: "F11", 5: "G11", 6: "H11",
        7: "I11", 8: "J11", 9: "K11", 10: "L11", 11: "M11", 12: "N11"
    }
    return month_columns.get(month_number)        



@job
def parse_convert_data_job(): # This is a placeholder job that won't actually be executed directly
    process_mm_bil_data()   